--	From Real SQL Queries: 50 Challenges

--Solution to Challenge Question 4: Upsell Tuesdays

SELECT 
	DayCategory =		DATENAME (WEEKDAY, OrderDate)
	,Revenue =			SUM (Subtotal)
	,Orders =			COUNT (*)
	,RevenuePerOrder =	SUM (Subtotal) / COUNT (*)
FROM Sales.SalesOrderHeader
WHERE YEAR (OrderDate) = 2008 AND OnlineOrderFlag = 0
GROUP BY DATENAME (WEEKDAY, OrderDate)
ORDER BY RevenuePerOrder DESC





